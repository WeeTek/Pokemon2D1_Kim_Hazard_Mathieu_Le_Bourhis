document.addEventListener('DOMContentLoaded', () => {
  const typeColors = { "Bug": "#A8B820", "Dark": "#705848", "Dragon": "#7038F8", "Electric": "#F8D030", "Fairy": "#EE99AC", "Fighting": "#C03028", "Fire": "#FFA040", "Flying": "#A890F0", "Ghost": "#705898", "Grass": "#78C850", "Ground": "#E0C068", "Ice": "#98D8D8", "Normal": "#A8A878", "Poison": "#A040A0", "Psychic": "#F85888", "Rock": "#B8A038", "Steel": "#B8B8D0", "Water": "#6890F0" };

  const pokemonController = new PokemonController();
  const pokemonData = pokemonController.pokemonList;
  const pokemonTableBody = document.querySelector('#pokemon-table-body');
  const fastMovesBtn = document.querySelector('.fast-moves-btn');
  const chargeMovesBtn = document.querySelector('.charge-moves-btn');
  const statsContainer = document.querySelector('.stats-container');
  let pokemonFiltre = pokemonData;
  let selectedMoveType = null;
  let nextPageButton = document.getElementById('page_suivante');
  let previousPageButton = document.getElementById('page_precedente');
  let movesNextButton = document.getElementById('moves-next');
  let movesPreviousButton = document.getElementById('moves-previous');
  let page = 0;
  let pageSize = 25;
  let movesPage = 0;
  let movesPageSize = 8;

    /**
 * @brief Fonction de mise à jour des données en fonction des filtres.
 * @param {number|null} generation - Le numéro de génération ou null.
 * @param {string|null} type - Le type de Pokémon ou null.
 * @param {string|null} name - Le nom du Pokémon ou null.
 * @returns {Array} - Les Pokémon filtrés.
 */
  function updateData(generation = null, type = null, name = null) {
    let filteredPokemons = []; // Tableau pour stocker les Pokémon filtrés


    for (let i = 0; i < pokemonData.length; i++) {
      const pokemon = pokemonData[i];

      // Vérifie si le nom correspond, saute l'itération si ce n'est pas le cas
      if (pokemon.pokemon_name != name && name != null) {
        continue;
      }
      if (pokemon.generation != null) {
        if (generation != null && pokemon.generation.generation_number != generation) {

          continue;
        }
      } else {
        continue
      }
      if (type !== null && !pokemon.types.some(t => t.type_name === type)) {
        continue;
      }
      // Ajoute le Pokémon au tableau des résultats s'il passe tous les filtres
      filteredPokemons.push(pokemon);
    }
    filteredPokemons;
    return filteredPokemons; // Retourne les Pokémon filtrés

  }

    /**
 * @brief Fonction pour mettre à jour le tableau des Pokémon.
 */
  function updateTable() {
    pokemonTableBody.innerHTML = '';

    const startIndex = page * pageSize;
    const endIndex = startIndex + pageSize;
    let pokemonBuffer;
    pokemonBuffer = pokemonFiltre;

    for (let i = startIndex; i < endIndex && i < pokemonBuffer.length; i++) {
      const pokemon = pokemonBuffer[i];
      const pokemonRow = document.createElement('tr');

      const idCell = document.createElement('td');
      idCell.textContent = pokemon.pokemon_id;
      pokemonRow.appendChild(idCell);

      const nameCell = document.createElement('td');
      nameCell.textContent = pokemon.pokemon_name;
      pokemonRow.appendChild(nameCell);

      const genCell = document.createElement('td');
      genCell.textContent = `Gen ${pokemon.generation.generation_number}`;
      pokemonRow.appendChild(genCell);

      const attackCell = document.createElement('td');
        const attackIcon = document.createElement('img');
        attackIcon.src = "../css/icon/attack.png";
        attackIcon.style.width = "15px";
        attackIcon.style.height = "15px";
        attackCell.appendChild(attackIcon);
        attackCell.innerHTML += pokemon.base_attack; // Ajoutez la valeur d'attaque après l'icône
        pokemonRow.appendChild(attackCell);

        const defenseCell = document.createElement('td');
        const defenseIcon = document.createElement('img');
        defenseIcon.src = "../css/icon/defence.png";
        defenseIcon.style.width = "15px";
        defenseIcon.style.height = "15px";
        defenseCell.appendChild(defenseIcon);
        defenseCell.innerHTML += pokemon.base_defense; // Ajoutez la valeur d'attaque après l'icône
        pokemonRow.appendChild(defenseCell);

      const typesCell = document.createElement('td');
      const typeSpans = pokemon.types.map(type => {
        return `<span class="type" style="background-color: ${typeColors[type.type_name]};border-radius: 5px; padding: 5px 10px; color: white;"> 
  <img src="../css/icon/Pokemon_Type_Icon_${type.type_name}.png" style="width: 15px; height: 15px;" alt="${type.type_name}"/> 
  ${type.type_name}</span>`;
      });
      typesCell.innerHTML = typeSpans.join(' ');
      pokemonRow.appendChild(typesCell);


      const imageCell = document.createElement('td');
      const image = document.createElement('img');

      let imgSrcbuffer;
      pokemonRow.addEventListener('click', () => {
        selectedPokemon = pokemon;
        showModal(pokemon); // Ajoutez cet appel pour afficher le modal dès qu'un Pokémon est sélectionné
      });


      if (pokemon.pokemon_id < 10) {
        imgSrcbuffer = '00' + String(pokemon.pokemon_id);
      } else if (pokemon.pokemon_id < 100) {
        imgSrcbuffer = '0' + String(pokemon.pokemon_id);
      } else {
        imgSrcbuffer = String(pokemon.pokemon_id);
      }

      if (pokemon.pokemon_id <= 809) {
        image.src = `../webp/sprites/${imgSrcbuffer}MS.webp`;
      } else {
        image.src = `../webp/sprites/${imgSrcbuffer}.webp`;
      }
      imageCell.appendChild(image);
      pokemonRow.appendChild(imageCell);

      function showMoves(type, pokemon) {
        selectedMoveType = type;
        selectedPokemon = pokemon;
        let moves = (type === 'fast') ? pokemon.attacks.fast_moves : pokemon.attacks.charged_moves;
        const startIndex = movesPage * movesPageSize;
        const endIndex = startIndex + movesPageSize;
        moves = moves.slice(startIndex, endIndex);
        const movesHtml = '<ul>' + moves.map(move => `<li class="move">${move.name}</li>`).join('') + '</ul>';
        document.querySelector('.moves-container').innerHTML = '';
        document.querySelector('.moves-container').innerHTML = movesHtml;
        document.querySelector('.moves-container').style.display = 'block';
        document.querySelectorAll('.move').forEach(moveElement => {
          moveElement.addEventListener('click', () => {
            document.querySelectorAll('.move').forEach(move => move.classList.remove('selected'));
            moveElement.classList.add('selected');
            showStats(moveElement.textContent, pokemon);
          });
        });
      }

      function showStats(moveName) {
        const move = pokemon.attacks.fast_moves.find(move => move.name === moveName) ||
          pokemon.attacks.charged_moves.find(move => move.name === moveName);

        if (move) {
          const stats = {
            critical_chance: move.critical_chance || 0.05,
            duration: move.duration,
            energy_delta: move.energy_delta,
            move_id: move.move_id,
            power: move.power,
            stamina_loss_scaler: move.stamina_loss_scaler || 0.06,
            type: move.type
          };

          // Création de l'élément img pour l'icône de type
          const typeIcon = document.createElement('img');
          typeIcon.src = `../css/icon/Pokemon_Type_Icon_${stats.type}.png`;
          typeIcon.style.width = '15px';
          typeIcon.style.height = '15px';
          typeIcon.alt = stats.type;

          // Création du HTML des statistiques avec l'icône de type centrée verticalement à l'intérieur de la balise span
          const statsHtml = `
            <h3>Stats:</h3>
            <p class="stats">
              Type: 
              <span style="background-color: ${typeColors[stats.type]}; border-radius: 5px; padding: 5px 10px; color: white;">
                ${typeIcon.outerHTML} ${stats.type}
              </span>
            </p>
            <p class="stats">Critical Chance: ${stats.critical_chance}</p>
            <p class="stats">Duration: ${stats.duration}</p>
            <p class="stats">Energy Delta: ${stats.energy_delta}</p>
            <p class="stats">Power: ${stats.power}</p>
            <p class="stats">Stamina Loss Scaler: ${stats.stamina_loss_scaler}</p>
          `;

          // Affichage des statistiques dans le conteneur
          statsContainer.innerHTML = statsHtml;
        } else {
          console.log('Aucune attaque trouvée');
        }
      }
      let selectedPokemon = null;

      pokemonRow.addEventListener('click', () => {
        selectedPokemon = pokemon;
      });


      chargeMovesBtn.addEventListener('click', function () {
        if (selectedPokemon) {
          selectedMoveType = 'charged';
          lastSelectedMoveType = selectedMoveType; // Mettre à jour lastSelectedMoveType
          lastSelectedPokemon = selectedPokemon; // Mettre à jour lastSelectedPokemon
          showMoves(lastSelectedMoveType, lastSelectedPokemon);
          chargeMovesBtn.classList.add('active');
          fastMovesBtn.classList.remove('active');
          document.getElementById('moves-pagination').style.display = 'flex';

        }
      });

      fastMovesBtn.addEventListener('click', function () {
        if (selectedPokemon) {
          // Modifier la valeur de selectedMoveType lorsque vous cliquez sur le bouton "fast"
          selectedMoveType = 'fast';
          lastSelectedMoveType = selectedMoveType; // Mettre à jour lastSelectedMoveType
          lastSelectedPokemon = selectedPokemon; // Mettre à jour lastSelectedPokemon
          showMoves(lastSelectedMoveType, lastSelectedPokemon);
          fastMovesBtn.classList.add('active');
          chargeMovesBtn.classList.remove('active');
          document.getElementById('moves-pagination').style.display = 'flex';
        }
      });

      function showModal(pokemon) {
        document.querySelector('.nom').textContent = pokemon.pokemon_name;
        document.querySelector('.numero').textContent = `#${pokemon.pokemon_id}`;
        document.querySelector('.generation').textContent = `Gen ${pokemon.generation.generation_number}`;
        document.querySelector('.types').innerHTML = pokemon.types.map(type => `<p style="background-color: ${typeColors[type.type_name]}">${type.type_name}</p>`).join('');
        document.querySelector('.card img').src = `../webp/images/${String(pokemon.pokemon_id).padStart(3, '0')}.webp`;
        document.querySelector('.moves-container').style.display = 'none';
        openModal();
      }

      function openModal() {
        document.querySelector('.modal').style.display = 'block';
        document.querySelector('.overlay').style.display = 'block';
      }

      function closeModal() {
        document.querySelector('.modal').style.display = 'none';
        document.querySelector('.overlay').style.display = 'none';
        statsContainer.innerHTML = '';
        movesPage = 0;
        document.getElementById('moves-pagination').style.display = 'none';
      }

      function nextMovesPage() {
        console.log("selectedPokemon:", selectedPokemon);
        console.log("selectedMoveType:", selectedMoveType);
        if (selectedPokemon && selectedMoveType) {
          const moves = selectedPokemon.attacks[selectedMoveType + '_moves'];
          console.log("Moves:", moves);
          const maxMovesPage = Math.ceil(moves.length / movesPageSize) - 1;
          const reste = Math.ceil(moves.length % movesPageSize);
          if (reste > 0) {
            maxMovesPage++;
          }
          if (movesPage < maxMovesPage) {
            movesPage++;
            showMoves(selectedMoveType, selectedPokemon);
          }
        }
      }

      function previousMovesPage() {
        console.log("selectedPokemon:", selectedPokemon);
        console.log("selectedMoveType:", selectedMoveType);
        if (selectedPokemon && selectedMoveType && movesPage > 0) {
          movesPage--;
          showMoves(selectedMoveType, selectedPokemon);
        }
      }
      movesNextButton.addEventListener('click', nextMovesPage);
      movesPreviousButton.addEventListener('click', previousMovesPage);



      document.querySelector('.close').addEventListener('click', closeModal);

      document.querySelector('.close').addEventListener('click', closeModal);

      window.addEventListener('click', function (event) {
        if (event.target == document.querySelector('.modal')) {
          closeModal();
        }
      });

      pokemonRow.addEventListener('click', () => {
        showModal(pokemon);
      });

      // Créez une cellule pour l'image

      // Ajoutez l'événement de survol à la cellule de l'image
      imageCell.addEventListener('mouseover', () => {
        const imgSrc = `../webp/images/${String(pokemon.pokemon_id).padStart(3, '0')}.webp`;
        const hoverImage = document.getElementById('pokemon-hover-image');
        hoverImage.innerHTML = `<img src="${imgSrc}" alt="${pokemon.pokemon_name}" />`;
        hoverImage.style.display = 'block';
      });

      imageCell.addEventListener('mouseout', () => {
        const hoverImage = document.getElementById('pokemon-hover-image');
        hoverImage.style.display = 'none';
      });

      // Ajoutez l'image à la cellule d'image
      if (pokemon.pokemon_id <= 809) {
        image.src = `../webp/sprites/${imgSrcbuffer}MS.webp`;
      } else {
        image.src = `../webp/sprites/${imgSrcbuffer}.webp`;
      }
      imageCell.appendChild(image);
      pokemonRow.appendChild(imageCell);


      movesNextButton.addEventListener('click', function () {
        if (selectedPokemon) {
          if (selectedPokemon && selectedPokemon.attacks && selectedPokemon.attacks.charge_moves) {
            // Accéder à selectedPokemon.attacks.charge_moves.length en toute sécurité
          }

          const maxMovesPage = Math.ceil(selectedPokemon.attacks[selectedMoveType + '_moves'].length / movesPageSize) - 1;
          if (movesPage < maxMovesPage) {
            movesPage++;
            showMoves(selectedMoveType, selectedPokemon);
          }
        }
      });

      movesPreviousButton.addEventListener('click', function () {
        if (selectedPokemon && movesPage > 0) {
          movesPage--;
          showMoves(selectedMoveType, selectedPokemon);
        }
      });


      pokemonTableBody.appendChild(pokemonRow);
    }
  }

    /**
 * @brief Fonction pour passer à la page suivante du tableau des Pokémon.
 */
  function nextPage() {
    console.log("page suivante");
    page++;
    updateTable();
  }

    /**
 * @brief Fonction pour passer à la page précédente du tableau des Pokémon.
 */
  function previousPage() {
    console.log("page précédente");
    if (page > 0) {
      page--;
      updateTable();
    }
  }

    /**
 * @brief Fonction pour gérer les changements dans les filtres.
 */
  function handleFiltersChange() {
    let nameFilter = filterNameInput.value;
    let typeFilter = filterTypeInput.value;
    let generationFilter = filterGenerationSelect.value;


    if (nameFilter == "") {
      nameFilter = null;
    }
    // Vérification si le filtre de type est vide, si oui, passer à null
    if (typeFilter == "") {
      typeFilter = null;
    }

    // Vérification si l'option "Toutes" est sélectionnée pour le filtre de génération
    if (generationFilter === 'all') {
      generationFilter = null; // Passer null si l'option "Toutes" est sélectionnée
    }

    // Appeler updateTable avec les filtres combinés
    pokemonFiltre = updateData(generationFilter, typeFilter, nameFilter);
    updateTable(page);

  }


  const filterNameInput = document.getElementById('filter-name');
  const filterTypeInput = document.getElementById('filter-type');
  const filterGenerationSelect = document.getElementById('filter-generation');

  // Ajout d'écouteurs d'événements pour chaque filtre, appelant la fonction intermédiaire
  filterNameInput.addEventListener('input', handleFiltersChange);
  filterTypeInput.addEventListener('input', handleFiltersChange);
  filterGenerationSelect.addEventListener('change', handleFiltersChange);


  nextPageButton.addEventListener('click', nextPage);
  previousPageButton.addEventListener('click', previousPage);




  updateTable();
});

