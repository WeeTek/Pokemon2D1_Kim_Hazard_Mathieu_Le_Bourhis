document.addEventListener('DOMContentLoaded', () => {
  const typeColors = { "Bug": "#A8B820", "Dark": "#705848", "Dragon": "#7038F8", "Electric": "#F8D030", "Fairy": "#EE99AC", "Fighting": "#C03028", "Fire": "#FFA040", "Flying": "#A890F0", "Ghost": "#705898", "Grass": "#78C850", "Ground": "#E0C068", "Ice": "#98D8D8", "Normal": "#A8A878", "Poison": "#A040A0", "Psychic": "#F85888", "Rock": "#B8A038", "Steel": "#B8B8D0", "Water": "#6890F0" };

  const pokemonController = new PokemonController();
  const pokemonData = pokemonController.pokemonList;
  const pokemonTableBody = document.querySelector('#pokemon-table-body');
  let nextPageButton = document.getElementById('page_suivante');
  let previousPageButton = document.getElementById('page_precedente');
  let page = 0;
  let pageSize = 25;

      /**
 * @brief Fonction de mise à jour des données en fonction des filtres.
 * @param {number|null} generation - Le numéro de génération ou null.
 * @param {string|null} type - Le type de Pokémon ou null.
 * @param {string|null} name - Le nom du Pokémon ou null.
 * @returns {Array} - Les Pokémon filtrés.
 */
  function updateTable() {
    pokemonTableBody.innerHTML = '';

    const startIndex = page * pageSize;
    const endIndex = startIndex + pageSize;

    for (let i = startIndex; i < endIndex && i < pokemonData.length; i++) {
      const pokemon = pokemonData[i];
      const pokemonRow = document.createElement('tr');

      const idCell = document.createElement('td');
      idCell.textContent = pokemon.pokemon_id;
      pokemonRow.appendChild(idCell);

      const nameCell = document.createElement('td');
      nameCell.textContent = pokemon.pokemon_name;
      pokemonRow.appendChild(nameCell);

      const genCell = document.createElement('td');
      genCell.textContent = `Gen ${pokemon.generation.generation_number}`;
      pokemonRow.appendChild(genCell);

      const attackCell = document.createElement('td');
        const attackIcon = document.createElement('img');
        attackIcon.src = "../css/icon/attack.png";
        attackIcon.style.width = "15px";
        attackIcon.style.height = "15px";
        attackCell.appendChild(attackIcon);
        attackCell.innerHTML += pokemon.base_attack; // Ajoutez la valeur d'attaque après l'icône
        pokemonRow.appendChild(attackCell);

        const defenseCell = document.createElement('td');
        const defenseIcon = document.createElement('img');
        defenseIcon.src = "../css/icon/defence.png";
        defenseIcon.style.width = "15px";
        defenseIcon.style.height = "15px";
        defenseCell.appendChild(defenseIcon);
        defenseCell.innerHTML += pokemon.base_defense; // Ajoutez la valeur d'attaque après l'icône
        pokemonRow.appendChild(defenseCell);

        const typesCell = document.createElement('td');
        const typeSpans = pokemon.types.map(type => {
          return `<span class="type" style="background-color: ${typeColors[type.type_name]};border-radius: 5px; padding: 5px 10px; color: white;"> 
    <img src="../css/icon/Pokemon_Type_Icon_${type.type_name}.png" style="width: 15px; height: 15px;" alt="${type.type_name}"/> 
    ${type.type_name}</span>`;
        });
      typesCell.innerHTML = typeSpans.join(' ');
      pokemonRow.appendChild(typesCell);
      const imageCell = document.createElement('td');
      const image = document.createElement('img');
      let imgSrcbuffer;
      if (pokemon.pokemon_id < 10) {
        imgSrcbuffer = '00' + String(pokemon.pokemon_id);
      } else if (pokemon.pokemon_id < 100) {
        imgSrcbuffer = '0' + String(pokemon.pokemon_id);
      } else {
        imgSrcbuffer = String(pokemon.pokemon_id);
      }

      if (pokemon.pokemon_id <= 809) {
        image.src = `../webp/sprites/${imgSrcbuffer}MS.webp`;
      } else {
        image.src = `../webp/sprites/${imgSrcbuffer}.webp`;
      }
      imageCell.appendChild(image);
      pokemonRow.appendChild(imageCell);



      pokemonRow.addEventListener('click', () => {
        selectedPokemon = pokemon;
      });
      pokemonTableBody.appendChild(pokemonRow);
    }
  }

        /**
 * @brief Fonction pour passer à la page suivante du tableau des Pokémon.
 */
  function nextPage() {
    console.log("page suivante");
    page++;
    updateTable();
  }

        /**
 * @brief Fonction pour passer à la page précédente du tableau des Pokémon.
 */
  function previousPage() {
    console.log("page précédente");
    if (page > 0) {
      page--;
      updateTable();
    }
  }

  nextPageButton.addEventListener('click', nextPage);
  previousPageButton.addEventListener('click', previousPage);

  updateTable();
});

